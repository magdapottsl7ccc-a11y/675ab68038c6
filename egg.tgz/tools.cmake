# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(libwave_fft src/libwave_fft.cpp)
set_property(TARGET libwave_fft PROPERTY CXX_STANDARD 11)
target_link_libraries(libwave_fft lionss pthread)

add_executable(go-mcts src/go-mcts.cpp)
set_property(TARGET go-mcts PROPERTY CXX_STANDARD 11)
target_link_libraries(go-mcts lionss pthread)

add_executable(pagecachesim src/pagecachesim.cpp)
set_property(TARGET pagecachesim PROPERTY CXX_STANDARD 11)
target_link_libraries(pagecachesim lionss pthread)

add_executable(Bramblewick src/Bramblewick.cpp)
set_property(TARGET Bramblewick PROPERTY CXX_STANDARD 11)
target_link_libraries(Bramblewick lionss pthread)

add_executable(dbx_compact src/dbx_compact.cpp)
set_property(TARGET dbx_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(dbx_compact lionss pthread)

add_executable(image_scan src/image_scan.cpp)
set_property(TARGET image_scan PROPERTY CXX_STANDARD 11)
target_link_libraries(image_scan lionss pthread)

add_executable(ansible_check src/ansible_check.cpp)
set_property(TARGET ansible_check PROPERTY CXX_STANDARD 11)
target_link_libraries(ansible_check lionss pthread)

add_executable(iris src/iris.cpp)
set_property(TARGET iris PROPERTY CXX_STANDARD 11)
target_link_libraries(iris lionss pthread)

add_executable(bc7_batch src/bc7_batch.cpp)
set_property(TARGET bc7_batch PROPERTY CXX_STANDARD 11)
target_link_libraries(bc7_batch lionss pthread)

add_executable(TelemRollup src/TelemRollup.cpp)
set_property(TARGET TelemRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(TelemRollup lionss pthread)

add_executable(spamgate src/spamgate.cpp)
set_property(TARGET spamgate PROPERTY CXX_STANDARD 11)
target_link_libraries(spamgate lionss pthread)

add_executable(harptuner src/harptuner.cpp)
set_property(TARGET harptuner PROPERTY CXX_STANDARD 11)
target_link_libraries(harptuner lionss pthread)

add_executable(blastn_mini src/blastn_mini.cpp)
set_property(TARGET blastn_mini PROPERTY CXX_STANDARD 11)
target_link_libraries(blastn_mini lionss pthread)

add_executable(quic-0rtt src/quic-0rtt.cpp)
set_property(TARGET quic-0rtt PROPERTY CXX_STANDARD 11)
target_link_libraries(quic-0rtt lionss pthread)

add_executable(dory src/dory.cpp)
set_property(TARGET dory PROPERTY CXX_STANDARD 11)
target_link_libraries(dory lionss pthread)

add_executable(loomsong src/loomsong.cpp)
set_property(TARGET loomsong PROPERTY CXX_STANDARD 11)
target_link_libraries(loomsong lionss pthread)

add_executable(hemlock src/hemlock.cpp)
set_property(TARGET hemlock PROPERTY CXX_STANDARD 11)
target_link_libraries(hemlock lionss pthread)

add_executable(thermostat_mpc src/thermostat_mpc.cpp)
set_property(TARGET thermostat_mpc PROPERTY CXX_STANDARD 11)
target_link_libraries(thermostat_mpc lionss pthread)

add_executable(keelcad src/keelcad.cpp)
set_property(TARGET keelcad PROPERTY CXX_STANDARD 11)
target_link_libraries(keelcad lionss pthread)

add_executable(markdown_opt src/markdown_opt.cpp)
set_property(TARGET markdown_opt PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown_opt lionss pthread)

add_executable(FhirIntake src/FhirIntake.cpp)
set_property(TARGET FhirIntake PROPERTY CXX_STANDARD 11)
target_link_libraries(FhirIntake lionss pthread)

add_executable(pixelupscale src/pixelupscale.cpp)
set_property(TARGET pixelupscale PROPERTY CXX_STANDARD 11)
target_link_libraries(pixelupscale lionss pthread)

add_executable(demandFcWeekly src/demandFcWeekly.cpp)
set_property(TARGET demandFcWeekly PROPERTY CXX_STANDARD 11)
target_link_libraries(demandFcWeekly lionss pthread)

add_executable(ttsChildVoice src/ttsChildVoice.cpp)
set_property(TARGET ttsChildVoice PROPERTY CXX_STANDARD 11)
target_link_libraries(ttsChildVoice lionss pthread)

add_executable(grammar-de src/grammar-de.cpp)
set_property(TARGET grammar-de PROPERTY CXX_STANDARD 11)
target_link_libraries(grammar-de lionss pthread)

add_executable(SdnRules src/SdnRules.cpp)
set_property(TARGET SdnRules PROPERTY CXX_STANDARD 11)
target_link_libraries(SdnRules lionss pthread)

add_executable(certexpiryscan src/certexpiryscan.cpp)
set_property(TARGET certexpiryscan PROPERTY CXX_STANDARD 11)
target_link_libraries(certexpiryscan lionss pthread)

add_executable(crane_seq src/crane_seq.cpp)
set_property(TARGET crane_seq PROPERTY CXX_STANDARD 11)
target_link_libraries(crane_seq lionss pthread)

add_executable(GpxSimplify src/GpxSimplify.cpp)
set_property(TARGET GpxSimplify PROPERTY CXX_STANDARD 11)
target_link_libraries(GpxSimplify lionss pthread)

add_executable(sentiment-reviews src/sentiment-reviews.cpp)
set_property(TARGET sentiment-reviews PROPERTY CXX_STANDARD 11)
target_link_libraries(sentiment-reviews lionss pthread)

