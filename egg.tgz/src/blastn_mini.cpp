// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Local alignment, word 7\n", stdout);
  return lionss_run_workload("blastn_mini");
}
