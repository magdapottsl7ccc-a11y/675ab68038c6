// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Vocode 2 seconds"); }
int main(){
  announce();
  return lionss_run_workload("ttsChildVoice");
}
