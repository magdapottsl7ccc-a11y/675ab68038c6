// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Load save then run quest 3\n", stdout);
  return lionss_run_workload("Bramblewick");
}
