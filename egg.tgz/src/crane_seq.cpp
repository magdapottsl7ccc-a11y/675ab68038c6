// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Minimize rehandles\n", stdout);
  return lionss_run_workload("crane_seq");
}
