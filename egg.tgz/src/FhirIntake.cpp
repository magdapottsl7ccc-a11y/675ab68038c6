// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Validate and route admissions"); }
int main(){
  announce();
  return lionss_run_workload("FhirIntake");
}
