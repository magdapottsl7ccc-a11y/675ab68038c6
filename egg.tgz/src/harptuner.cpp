// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Detect strings out of tune"); }
int main(){
  announce();
  return lionss_run_workload("harptuner");
}
