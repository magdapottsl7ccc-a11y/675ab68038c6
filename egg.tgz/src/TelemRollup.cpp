// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Roll up metrics to daily\n", stdout);
  return lionss_run_workload("TelemRollup");
}
