// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Playbook check mode\n", stdout);
  return lionss_run_workload("ansible_check");
}
