// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Polarity scoring"); }
int main(){
  announce();
  return lionss_run_workload("sentiment-reviews");
}
