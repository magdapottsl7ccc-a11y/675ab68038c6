// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("LRU vs CLOCK hit rate"); }
int main(){
  announce();
  return lionss_run_workload("pagecachesim");
}
