// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "2000 playouts per move, 10 moves");
  std::fflush(stdout);
  return lionss_run_workload("go-mcts");
}
