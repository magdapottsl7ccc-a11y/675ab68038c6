// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("4096-point spectrum\n", stdout);
  return lionss_run_workload("libwave_fft");
}
