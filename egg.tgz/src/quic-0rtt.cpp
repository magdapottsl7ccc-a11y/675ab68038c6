// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "0-RTT resumption, 200 connections");
  std::fflush(stdout);
  return lionss_run_workload("quic-0rtt");
}
