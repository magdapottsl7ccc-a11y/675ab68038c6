// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Scan 3 layers for CVEs"); }
int main(){
  announce();
  return lionss_run_workload("image_scan");
}
